package tests
import physics.Physics
import physics.{World}
import org.scalatest.FunSuite

class TestUpdateWorld {
  test("detect collisions")
}
