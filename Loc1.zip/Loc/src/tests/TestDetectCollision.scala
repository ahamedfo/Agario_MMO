package tests

import org.scalatest.FunSuite
import physics.{Boundary, PhysicalObject,PhysicsVector,Physics}

class TestDetectCollision extends FunSuite{
test("detect Collisions"){
  val velocity = new PhysicsVector(206,250,240)
  var Object1 = new PhysicalObject(velocity,velocity)
  var velocity1 = new Boundary(velocity,velocity)
  assert(Physics.detectCollision(Object1, velocity, velocity1) == false)
}
}
