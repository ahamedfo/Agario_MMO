package physics

import scala.util.control.Breaks

object Physics {
  def updateVelocity(objectss: PhysicalObject, world: World, time: Double): Unit = {
    var z = (objectss.velocity.z - world.gravity * time)
    if (objectss.location.z == 0.0 && z < 0.0) {
      z = 0.0
    }
    objectss.velocity.z = z
  }

  def computePotentialLocation(Object1: PhysicalObject, time: Double): PhysicsVector = {
    var colliding: PhysicsVector = new PhysicsVector(0.0, 0.0, 0.0)
    colliding.x = Object1.location.x + (Object1.velocity.x * time)
    colliding.y = Object1.location.y + (Object1.velocity.y * time)
    colliding.z = Object1.location.z + (Object1.velocity.z * time)
    if (colliding.z < 0) {
      colliding.z = 0.0
    }
    colliding
  }

  def detectCollision(Object1: PhysicalObject, potentialLocation: PhysicsVector, boundary: Boundary): Boolean = {
    var xOBJ: Double = potentialLocation.x - Object1.location.x
    var yOBJ: Double = potentialLocation.y - Object1.location.y
    var m: Double = yOBJ / xOBJ
    var b: Double = potentialLocation.y - (m * potentialLocation.x)
    var Xbound: Double = boundary.end.x - boundary.start.x
    var Ybound: Double = boundary.end.y - boundary.start.y
    var mBound: Double = Ybound / Xbound
    var bBound: Double = boundary.end.y - (mBound * boundary.end.x)
    var x: Double = ((b - bBound) / (m - mBound))
    var y1: Double = (mBound * x) + bBound
    var y2: Double = (m * x) + b
    if (y1 == y2) {
      true
    }
    else {
      false
    }
  }

  def updateWorld(world: World, time: Double): Unit = {
    val loop = new Breaks
    for (item <- world.objects) {
      updateVelocity(item, world, time)
      var potential_Location: PhysicsVector = computePotentialLocation(item, time)
      loop.breakable {
        for (boundaries <- world.boundaries) {
          if (detectCollision(item, potential_Location, boundaries) == true) {
            item.location.z = potential_Location.z
            loop.break()
          }
          else {
            item.location = potential_Location
          }
        }
      }
    }
  }
}