package physics

import scala.util.control.Breaks
import java.awt.geom.Line2D.linesIntersect

object Physics {
  def updateVelocity(objectss: PhysicalObject, world: World, time: Double): Unit = {
    var z = (objectss.velocity.z - world.gravity * time)
    if (objectss.location.z == 0.0 && z < 0.0) {
      z = 0.0
    }
    objectss.velocity.z = z
  }

  def computePotentialLocation(Object1: PhysicalObject, time: Double): PhysicsVector = {
    var colliding: PhysicsVector = new PhysicsVector(0.0, 0.0, 0.0)
    colliding.x = Object1.location.x + (Object1.velocity.x * time)
    colliding.y = Object1.location.y + (Object1.velocity.y * time)
    colliding.z = Object1.location.z + (Object1.velocity.z * time)
    if (colliding.z < 0) {
      colliding.z = 0.0
    }
    colliding
  }

  def detectCollision(physicalObject: PhysicalObject, vector: PhysicsVector, boundary: Boundary): Boolean={
    linesIntersect(physicalObject.location.x,physicalObject.location.y,vector.x,vector.y,boundary.start.x,boundary.start.y,boundary.end.x,boundary.end.y)
  }



  def updateWorld(world: World, time: Double): Unit = {
    for (item <- world.objects) {
      updateVelocity(item, world, time)
      var potential_Location: PhysicsVector = computePotentialLocation(item, time)
      var x: Double = potential_Location.x
      var y: Double = potential_Location.y
      var z: Double = potential_Location.z
      var Real_locX: Double = item.location.x
      var Real_locY: Double = item.location.y
      for (boundaries <- world.boundaries) {
        if(detectCollision(item, potential_Location, boundaries)){
          x = Real_locX
          y = Real_locY
        }
      }
      item.location.x = x
      item.location.y = y
      item.location.z = z
    }
  }
}