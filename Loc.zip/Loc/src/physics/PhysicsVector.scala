package physics

class PhysicsVector(var x: Double, var y: Double, var z: Double) {

}