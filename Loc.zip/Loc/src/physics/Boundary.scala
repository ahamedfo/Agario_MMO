package physics

class Boundary(var start:PhysicsVector, var end: PhysicsVector) {

}

