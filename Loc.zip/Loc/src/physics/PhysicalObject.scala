package physics

class PhysicalObject(var location: PhysicsVector, var velocity: PhysicsVector) {

}

